import React from 'react';
import './LoginForm.css'
import ReCAPTCHA from "react-google-recaptcha";


const LoginForm = () => {
    const onChange = () => {};
  return (
    <div className='wrapper'>
      <div className="form-box login">
        <form>
          <h2>Login</h2>
          <div className="form-group">
            <label htmlFor="registrationId">Registration ID</label>
            <input type="text" id="registrationId" placeholder="Enter registration ID" required />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input type="password" id="password" placeholder="Enter password" required />
          </div>
          <div className="forgot-password">
            <a href="#">Forgot password?</a>
          </div>
          <ReCAPTCHA sitekey="6LfcYQIqAAAAADK2WvuKk8_M-uBZGwALpBNahxte" onChange={onChange}/>,
          <button type="submit">Login</button>
          <div className="registration-link">
            <p>Don't have an account? <a href="#">Register</a></p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
