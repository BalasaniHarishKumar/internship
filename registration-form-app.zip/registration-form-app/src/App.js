// src/App.js

import React from 'react';
import './App.css'; // Optional: You can create App.css for styling
import RegistrationForm from './RegistrationForm';
// import registration-backend from './'
function App() {
  return (
    <div className="App">
      <main className="App-main">
        <RegistrationForm />
      </main>
    </div>
  );
}

export default App;
