import React, { useState } from 'react';
import axios from 'axios';
import './RegistrationForm.css'; // Import CSS file for styling

const districts = ['District A', 'District B', 'District C']; // Example districts
const mandals = ['Mandal X', 'Mandal Y', 'Mandal Z']; // Example mandals
const villages = ['Village 1', 'Village 2', 'Village 3']; // Example villages

const baseUrl = 'http://localhost:5000/registrations'; // Replace with your backend URL

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    registrationNumber: '',
    applicantName: '',
    casteCode: '',
    aadhaarNumber: '',
    district: '',
    mandal: '',
    village: '',
    address: '',
    street: '',
    landmark: '',
    pinCode: '',
    mobileNumber: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleReset = () => {
    setFormData({
      registrationNumber: '',
      applicantName: '',
      casteCode: '',
      aadhaarNumber: '',
      district: '',
      mandal: '',
      village: '',
      address: '',
      street: '',
      landmark: '',
      pinCode: '',
      mobileNumber: '',
    });
  };

  const handleVerify = (e) => {
    e.preventDefault(); // Prevent default form submission

    axios.post(baseUrl, formData)
      .then(response => {
        console.log('Registration successful:', response.data);
        // Optionally, handle success message or redirect
      })
      .catch(error => {
        console.error('Registration failed:', error);
        // Optionally, handle error message
      });
  };

  return (
    <div className="container">
      <h3>Registration Form</h3>
      <form onSubmit={handleVerify}>
        <div className="form-group">
          <label htmlFor="registrationNumber">Registration Number:</label>
          <input
            type="text"
            id="registrationNumber"
            name="registrationNumber"
            value={formData.registrationNumber}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="applicantName">Name of Applicant:</label>
          <input
            type="text"
            id="applicantName"
            name="applicantName"
            value={formData.applicantName}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="casteCode">Caste Code:</label>
          <input
            type="text"
            id="casteCode"
            name="casteCode"
            value={formData.casteCode}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="aadhaarNumber">Aadhaar Number:</label>
          <input
            type="text"
            id="aadhaarNumber"
            name="aadhaarNumber"
            value={formData.aadhaarNumber}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="district">District:</label>
          <select
            id="district"
            name="district"
            value={formData.district}
            onChange={handleChange}
            required
          >
            <option value="">Select District</option>
            {districts.map((district) => (
              <option key={district} value={district}>
                {district}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="mandal">Mandal:</label>
          <select
            id="mandal"
            name="mandal"
            value={formData.mandal}
            onChange={handleChange}
            required
          >
            <option value="">Select Mandal</option>
            {mandals.map((mandal) => (
              <option key={mandal} value={mandal}>
                {mandal}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="village">Village:</label>
          <select
            id="village"
            name="village"
            value={formData.village}
            onChange={handleChange}
            required
          >
            <option value="">Select Village</option>
            {villages.map((village) => (
              <option key={village} value={village}>
                {village}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="address">Address:</label>
          <textarea
            id="address"
            name="address"
            value={formData.address}
            onChange={handleChange}
            rows="4"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="street">Street:</label>
          <input
            type="text"
            id="street"
            name="street"
            value={formData.street}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="landmark">Landmark:</label>
          <input
            type="text"
            id="landmark"
            name="landmark"
            value={formData.landmark}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="pinCode">Pin Code:</label>
          <input
            type="text"
            id="pinCode"
            name="pinCode"
            value={formData.pinCode}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="mobileNumber">Mobile Number:</label>
          <input
            type="text"
            id="mobileNumber"
            name="mobileNumber"
            value={formData.mobileNumber}
            onChange={handleChange}
            required
          />
        </div>

        <div className="button-group">
          <button type="submit" className="btn-verify">Verify</button>
          <button type="button" className="btn-reset" onClick={handleReset}>Reset</button>
        </div>
      </form>
    </div>
  );
};

export default RegistrationForm;
