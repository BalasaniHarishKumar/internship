// index.js

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const Registration = require('./models/Registration'); // Create this model later

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

// MongoDB Connection
const MONGODB_URI = 'mongodb://localhost:27017/registrationDB'; // Replace with your MongoDB connection string
mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const connection = mongoose.connection;
connection.once('open', () => {
  console.log('MongoDB connection established successfully');
});

// Routes
const registrationRouter = require('./routes/registration');
app.use('/registrations', registrationRouter);

// Start Server
app.listen(PORT, () => {
  console.log(`Server is running on port: ${PORT}`);
});
