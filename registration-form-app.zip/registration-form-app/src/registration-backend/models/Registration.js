// models/Registration.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const registrationSchema = new Schema({
  registrationNumber: { type: String, required: true },
  applicantName: { type: String, required: true },
  casteCode: { type: String, required: true },
  aadhaarNumber: { type: String, required: true },
  district: { type: String, required: true },
  mandal: { type: String, required: true },
  village: { type: String, required: true },
  address: { type: String, required: true },
  street: { type: String, required: true },
  landmark: { type: String, required: true },
  pinCode: { type: String, required: true },
  mobileNumber: { type: String, required: true },
});

const Registration = mongoose.model('Registration', registrationSchema);
module.exports = Registration;
