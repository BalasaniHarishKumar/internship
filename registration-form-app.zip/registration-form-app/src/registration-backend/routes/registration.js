// routes/registration.js

const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');

// Create a new registration
router.post('/', (req, res) => {
  const newRegistration = new Registration(req.body);
  newRegistration.save()
    .then(() => res.json('Registration added!'))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Fetch all registrations
router.get('/', (req, res) => {
  Registration.find()
    .then(registrations => res.json(registrations))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Fetch a specific registration by ID
router.get('/:id', (req, res) => {
  Registration.findById(req.params.id)
    .then(registration => res.json(registration))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Update a registration by ID
router.put('/:id', (req, res) => {
  Registration.findById(req.params.id)
    .then(registration => {
      registration = Object.assign(registration, req.body);
      registration.save()
        .then(() => res.json('Registration updated!'))
        .catch(err => res.status(400).json('Error: ' + err));
    })
    .catch(err => res.status(400).json('Error: ' + err));
});

// Delete a registration by ID
router.delete('/:id', (req, res) => {
  Registration.findByIdAndDelete(req.params.id)
    .then(() => res.json('Registration deleted.'))
    .catch(err => res.status(400).json('Error: ' + err));
});

module.exports = router;
