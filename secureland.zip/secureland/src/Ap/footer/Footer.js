import React from 'react'
import './Footer.css'
const Footer = () => {
  return (
    <div className='container-fluid foot'>
      <h4 className='footer-name'>Copyright &copy; All rights reserved with Chief Commissioner of Land Administration, Govt.of Telangana</h4>
    </div>
  )
}

export default Footer