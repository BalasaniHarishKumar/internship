// src/Navbar.js
import React from 'react';
import './Nav.css'
import cm from '../images/cm.png' 
import logo from '../images/telangana_logo.png'

const Nav = () => {
  return (
    <div className="navbar sticky-top">
      <div className="navbar-left">
        <img src={logo} alt="Logo" className="logo" />
        <h1 className="title">Secure Land Management</h1>
      </div>
      <div className="navbar-right">
        <div className="profile">
          <img  alt="Minister" className="profile-image" />
          <div className="profile-info">
            <p className="profile-name">Minister Name</p>
            <p className="profile-designation">Designation</p>
          </div>
        </div>
        <div className="profile">
          <img src={cm} alt="Chief Minister" className="profile-image" />
          <div className="profile-info">
            <p className="profile-name">Revanth Reddy</p>
            <p className="profile-designation">Chief Minister - Telangana</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Nav;
