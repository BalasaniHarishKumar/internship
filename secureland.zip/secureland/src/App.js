import Nav from './Ap/navbar/Nav'
import MainPage, { AddressContext } from './Ap/mainPage/MainPage'
import Footer from './Ap/footer/Footer'
import OfficialRegistration from './Ap/officialRegistration/OfficialRegistration'
import UserRegister from './Ap/userRegisteration/UserRegister'
import './App.css';
import MainComponent from './MainComponent';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import { useState } from 'react'
import UserRegPage2 from './Ap/userRegisteration/UserRegPage2'
function App() {
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedMandal, setSelectedMandal] = useState('');
  const [selectedVillage, setSelectedVillage] = useState(''); 
  return (
    <div>
      {/* <MainComponent /> */}
      {/* Routing */}
      <AddressContext.Provider value={{selectedDistrict,setSelectedDistrict,selectedMandal,setSelectedMandal,selectedVillage,setSelectedVillage}}>
        <Routes>
          <Route path="/" element={<MainComponent/>} />
          <Route path="/nav" element={<Nav />}/>
          <Route path="/mainPage" element={<MainPage />}/>
          <Route path="/footer" element={<Footer />}/>
          <Route path='/officeReg' element={<OfficialRegistration />} />
          <Route path='/userReg' element={<UserRegister />} />
          <Route path='/Registration/step-2' element={<UserRegPage2 />} />
          <Route path='*' element={"Page Not Found"} />
        </Routes>
      </AddressContext.Provider>
    </div>
  );
}

export default App;
